package model;

public class TemperatureSensor extends Sensor{

    @Override
    public void setSensorName(String sensorName) {
        super.sensorName = sensorName;
    }

    public void setSensorType(String sensorType){
        super.sensorType = sensorType;
    }

    public void setSensorCost(double sensorCost){
        super.sensorCost = sensorCost;
    }

    public String getSensorName(){
        return super.sensorName;
    }

    public String getSensorType(){
        return super.sensorType;
    }

    public int getSensorCost(){
        return 20;
    }

    @Override
    public void displaySensorInfo() {
        super.displaySensorInfo();
    }

//    public static TemperatureSensor getInstance() {
//        return new TemperatureSensor();
//    }
}

