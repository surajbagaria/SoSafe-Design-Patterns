package model;

public class SecurityService extends Service {
    public SecurityService(String serviceType) {
        super(serviceType);
    }
}
