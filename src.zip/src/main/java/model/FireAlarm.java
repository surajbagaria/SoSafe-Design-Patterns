package model;

public class FireAlarm extends Alarm {//create one after press triggle
    public int alarmID;
    public String alarmLocation;
    public boolean alarmStatus;

    public static FireAlarm getInstance() {
        return new FireAlarm();
    }
}
