package model;

public class FireAlarmService extends Service {
    public FireAlarmService(String serviceType) {
        super(serviceType);
    }
}
