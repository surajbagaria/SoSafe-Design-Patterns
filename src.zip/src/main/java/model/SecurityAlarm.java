package model;

public class SecurityAlarm extends Alarm{
    public int alarmID;
    public String alarmLocation;
    public boolean alarmStatus;

    public SecurityAlarm getInstance() {
        return new SecurityAlarm();
    }

}
