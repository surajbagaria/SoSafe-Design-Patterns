package model;

public abstract class Alarm {
    public int alarmID;
    public String alarmLocation;
    public boolean alarmStatus;

}
