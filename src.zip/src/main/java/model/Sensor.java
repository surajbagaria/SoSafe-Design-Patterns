package model;

public abstract class Sensor {

    public int sensorID;
    public String sensorName;
    public String sensorType;
    public boolean sensorStatus;
    public double sensorCost;
    public boolean breakIn;
    public String location;

    //Setters
    public void setSensorID(int sensorID) {
        this.sensorID = sensorID;
    }

    public abstract void setSensorName(String sensorName);

    public abstract void setSensorType(String sensorType);

    public void setSensorStatus(boolean sensorStatus) {
        this.sensorStatus = sensorStatus;
    }

    public abstract void setSensorCost(double sensorCost);

    public void setLocation(String location) {
        this.location = location;
    }

    //Getters
    public int getSensorID() {
        return this.sensorID;
    }

    public abstract String getSensorName();

    public abstract String getSensorType();

    public boolean getSensorStatus() {
        return this.sensorStatus;
    }

    public abstract int getSensorCost();

    public boolean getBreakIn() {
        return this.breakIn;
    }

    public String getLocation() {
        return this.location;
    }

    public void displaySensorInfo() {
        System.out.println("Sensor ID: " + this.getSensorID() + " Sensor Name: " + this.getSensorName() + " Sensor Type: " + this.getSensorType() + " Sensor Status: " + this.getSensorStatus() + " Sensor Cost: " + this.getSensorCost() + " Break In: " + this.getBreakIn() + " Location: " + this.getLocation());
    }

}