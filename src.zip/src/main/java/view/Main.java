package view;

import controller.DisplayPanel;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main (String[] args) {
        new SignInFrame();
    }
}
